
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY_HERE';

const App = () => {
  const [input, setInput] = useState('');
  const [chat, setChat] = useState(() => {
    const saved = localStorage.getItem('chat-history');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('chat-history', JSON.stringify(chat));
  }, [chat]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const newMessage = { role: 'user', content: input };
    setChat(prev => [...prev, newMessage]);
    setInput('');

    try {
      const res = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' + GEMINI_API_KEY, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: input }] }] })
      });
      const data = await res.json();
      const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response.';
      setChat(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch (err) {
      setChat(prev => [...prev, { role: 'assistant', content: 'Error fetching response.' }]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-2xl font-bold text-center mb-4">Ayman Ahmad's Web Assistant</h1>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="md:col-span-3">
          <Card className="h-[70vh] overflow-y-auto space-y-2 p-2">
            <CardContent>
              {chat.map((msg, idx) => (
                <div key={idx} className={`mb-2 p-2 rounded ${msg.role === 'user' ? 'bg-blue-100 text-left' : 'bg-green-100 text-left'}`}>
                  <strong>{msg.role === 'user' ? 'You' : 'Assistant'}:</strong>
                  <pre className="whitespace-pre-wrap">{msg.content}</pre>
                </div>
              ))}
            </CardContent>
          </Card>
          <div className="mt-2 flex gap-2">
            <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask a question or request code..." />
            <Button onClick={handleSend}>Send</Button>
          </div>
        </div>
        <div className="bg-white rounded p-3 shadow">
          <h2 className="font-semibold text-lg mb-2">Chat History</h2>
          <ul className="text-sm space-y-1 max-h-[70vh] overflow-y-auto">
            {chat.map((item, idx) => (
              <li key={idx} className="truncate">
                <strong>{item.role === 'user' ? 'Q:' : 'A:'}</strong> {item.content.slice(0, 50)}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default App;
